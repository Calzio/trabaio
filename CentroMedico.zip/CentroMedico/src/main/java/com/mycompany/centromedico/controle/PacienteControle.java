/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centromedico.controle;

import com.mycompany.centromedico.dao.PacienteDAO;
import com.mycompany.centromedico.modelo.Paciente;
import java.util.List;

public class PacienteControle {

    private PacienteDAO pacienteDAO = new PacienteDAO();

    public void adicionarPaciente(String nome, String cpf, String telefone, String relatorio) {
        Paciente paciente = new Paciente(nome, cpf, telefone, relatorio);
        pacienteDAO.inserir(paciente);
    }

    public List<Paciente> listarPacientes() {
        return pacienteDAO.listar();
    }

    public void atualizarPaciente(Paciente paciente) {
        pacienteDAO.atualizar(paciente);
    }

    public void removerPaciente(int id) {
        pacienteDAO.remover(id);
    }
}
