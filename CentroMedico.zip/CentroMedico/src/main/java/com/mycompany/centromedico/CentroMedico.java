/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.centromedico;
import com.mycompany.centromedico.view.TelaEscolha;
/**
 *
 * @author aluno.den
 */
public class CentroMedico {

    public static void main(String[] args) {
        TelaEscolha e = new TelaEscolha();
        e.setVisible(true);
        
        }
}
