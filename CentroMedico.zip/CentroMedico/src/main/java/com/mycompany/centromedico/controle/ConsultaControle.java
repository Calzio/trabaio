/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centromedico.controle;

import com.mycompany.centromedico.dao.ConsultaDAO;
import com.mycompany.centromedico.modelo.Consulta;
import java.util.List;

public class ConsultaControle {

    private ConsultaDAO consultaDAO = new ConsultaDAO();

    public void agendarConsulta(int idPaciente, int idMedico, String data, String hora, String observacao) {
        java.sql.Date dataConvertida = java.sql.Date.valueOf(data);
        java.sql.Time horaConvertida = java.sql.Time.valueOf(hora);
        Consulta consulta = new Consulta(0, idPaciente, idMedico, data, hora, observacao);
        consultaDAO.inserir(consulta);
    }

    public List<Consulta> listarConsultas() {
        return consultaDAO.listar();
    }

    public List<Consulta> buscarPorPaciente(int idPaciente) {
        return consultaDAO.buscarPorPaciente(idPaciente);
    }

    public List<Consulta> buscarPorData(String data) {
        return consultaDAO.buscarPorData(data);
    }

    public void atualizarConsulta(Consulta consulta) {
        consultaDAO.atualizar(consulta);
    }

    public void cancelarConsulta(int id) {
        consultaDAO.remover(id);
    }
}